#!/bin/bash
# ============================================================================
# nasscad.sh -- starts the MEDUSA engine and opens NASSCAD in your browser.
#
# Native Linux counterpart of medusa.bat. Put it next to the NASSCAD page
# (NASSCAD_*.htm), or anywhere above it, and run:
#
#     bash nasscad.sh
#
#     --stop        stop the engine and exit
#     --no-browser  start the engine only, do not open a page
#     --logfile     ask the engine to also write medusa-logs-<date>.txt
# ============================================================================
set -u

HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
ENGINE="$HOME/nasscad-medusa/engine/nasscad_medusa"
# [28/09 — audit] La page est cherchee par MOTIF (NASSCAD_*.htm), comme le fait
# nasscad.bat sous Windows : le nom code en dur (NASSCAD_V4_7_0.htm) cassait le
# lanceur des le prochain changement de version. Plusieurs versions cote a cote :
# la plus recente au sens du nom (V4_7_2 apres V4_7_0).
PAGE_GLOB="NASSCAD_*.htm"
PORT=8765
LOG="/tmp/nasscad_medusa.log"
# En-tete de session pour les sondes du lanceur : le moteur n'annonce ainsi
# « NASSCAD reconnected » qu'une fois pour le lanceur, pas a chaque sonde.
PING_HDR="X-NASSCAD-Session: nasscad.sh"

OPEN_BROWSER=1
BACKGROUND=0
# Passed through to the engine itself. Empty by default: since the 04/09 build
# the engine writes NO log file unless asked, and its journal is read on demand
# over GET /log (the jellyfish button in the NASSCAD Logs panel). --logfile
# restores the old medusa-logs-<date>.txt written at startup.
# Opens a command in a visible terminal window (engine, log follower).
# [28/09 — audit] Extrait de start_in_terminal pour servir aussi a --log.
open_terminal() {
    local title="$1" cmd="$2"
    if   command -v gnome-terminal   >/dev/null 2>&1; then gnome-terminal --title="$title" -- bash -c "$cmd"
    elif command -v konsole          >/dev/null 2>&1; then konsole --hold -p tabtitle="$title" -e bash -c "$cmd"
    elif command -v xfce4-terminal   >/dev/null 2>&1; then xfce4-terminal --title="$title" -e "bash -c \"$cmd\""
    elif command -v mate-terminal    >/dev/null 2>&1; then mate-terminal --title="$title" -e "bash -c \"$cmd\""
    elif command -v tilix            >/dev/null 2>&1; then tilix -t "$title" -e bash -c "$cmd"
    elif command -v kitty            >/dev/null 2>&1; then kitty --title "$title" bash -c "$cmd"
    elif command -v alacritty        >/dev/null 2>&1; then alacritty -t "$title" -e bash -c "$cmd"
    elif command -v x-terminal-emulator >/dev/null 2>&1; then x-terminal-emulator -T "$title" -e bash -c "$cmd"
    elif command -v xterm            >/dev/null 2>&1; then xterm -T "$title" -e bash -c "$cmd"
    else return 1
    fi
    return 0
}

# Opens the engine in a visible terminal window, the way medusa.bat does on
# Windows. Same reasoning: you read the log live, and closing the window stops
# the engine -- no PID to hunt. Falls back to a detached process when no
# terminal emulator is available (a server, an SSH session, a bare TTY).
start_in_terminal() {
    local dir
    dir="$(dirname "$ENGINE")"
    open_terminal "NASSCAD MEDUSA Engine" "cd '$dir'; exec ./nasscad_medusa $ENGINE_ARGS"
}

ENGINE_ARGS=""
for a in "${@:-}"; do
    case "$a" in
        --stop)
            # [28/09 — audit] Nom de processus EXACT : l'ancien motif -f 'nasscad_medusa$'
            # ratait un moteur lance avec un argument (--logfile).
            if pkill -x nasscad_medusa 2>/dev/null; then
                echo "  MEDUSA stopped."
            else
                echo "  MEDUSA was not running."
            fi
            exit 0 ;;
        --log)
            [ -f "$LOG" ] || { echo "  No log yet: $LOG"; exit 1; }
            # [28/09 — audit] Lance depuis l'icone (« Follow the engine log »), il n'y a
            # pas de terminal : tail -f tournait invisible et n'affichait rien. Sans
            # terminal attache, on en ouvre un, comme pour le moteur lui-meme.
            if [ ! -t 1 ] && [ -n "${DISPLAY:-}${WAYLAND_DISPLAY:-}" ] \
               && open_terminal "NASSCAD MEDUSA log" "exec tail -f '$LOG'" 2>/dev/null; then
                exit 0
            fi
            echo "  Following $LOG -- Ctrl+C to stop watching (the engine keeps running)."
            exec tail -f "$LOG" ;;
        --no-browser) OPEN_BROWSER=0 ;;
        --background) BACKGROUND=1 ;;
        --logfile)    ENGINE_ARGS="--logfile" ;;
        "" ) ;;
        *) echo "Unknown option: $a"; exit 1 ;;
    esac
done


echo "============================================================"
echo "  NASSCAD -- launcher"
echo "============================================================"

# -- 1. Find the page --------------------------------------------------------
# By content, not by folder name: the right folder is the one holding the page.
# Looked for next to this script first, then one level up, then in the usual
# places. A renamed folder must not break the launcher.
# La page la plus recente d'un dossier (motif PAGE_GLOB), ou rien.
page_in() {
    local f last=""
    for f in "$1"/$PAGE_GLOB; do [ -f "$f" ] && last="$f"; done
    [ -n "$last" ] && echo "$(cd "$(dirname "$last")" && pwd)/$(basename "$last")"
}
PAGE=""
for d in "$HERE" "$HERE/.." "$HERE/../.." "$HOME/NASSCAD" "$HOME/Downloads"; do
    PAGE="$(page_in "$d")"; [ -n "$PAGE" ] && break
done
if [ -z "$PAGE" ]; then
    for d in "$HOME"/*NASSCAD*/ "$HOME"/Downloads/*NASSCAD*/; do
        [ -d "$d" ] || continue
        PAGE="$(page_in "${d%/}")"; [ -n "$PAGE" ] && break
    done
fi
PAGE_NAME="$(basename "${PAGE:-$PAGE_GLOB}")"
if [ -z "$PAGE" ] && [ "$OPEN_BROWSER" = "1" ]; then
    echo "  WARNING: no $PAGE_GLOB page found. Starting the engine only."
    OPEN_BROWSER=0
fi
[ -n "$PAGE" ] && echo "  Page   : $PAGE"

# -- 2. Engine present? ------------------------------------------------------
if [ ! -x "$ENGINE" ]; then
    echo ""
    echo "  ERROR: engine not built."
    echo "         Expected: $ENGINE"
    echo "         Run once:  bash install-linux.sh"
    exit 1
fi
echo "  Engine : $ENGINE"

# -- 3. Already running? -----------------------------------------------------
# A second instance would die on bind() -- port already taken. Reuse it.
if curl -s -f -m 2 -H "$PING_HDR" "http://127.0.0.1:$PORT/ping" >/dev/null 2>&1; then
    echo "  MEDUSA is ALREADY running -- reusing it."
else
    echo "  Starting MEDUSA..."
    VISIBLE=0
    if [ "$BACKGROUND" = "0" ] && [ -n "${DISPLAY:-}${WAYLAND_DISPLAY:-}" ] && start_in_terminal 2>/dev/null; then
        VISIBLE=1
        echo "  Engine window opened -- close it to stop the engine."
    else
        # $ENGINE_ARGS non quote EXPRES : vide, il doit disparaitre, pas devenir
        # un argument vide que le moteur rejetterait.
        ( cd "$(dirname "$ENGINE")" && nohup ./nasscad_medusa $ENGINE_ARGS >"$LOG" 2>&1 & )
        echo "  Engine started in the background -- log: $LOG"
        echo "  Follow it with: bash nasscad.sh --log"
    fi
    READY=0
    for _ in $(seq 1 20); do
        if curl -s -f -m 2 -H "$PING_HDR" "http://127.0.0.1:$PORT/ping" >/dev/null 2>&1; then READY=1; break; fi
        sleep 1
    done
    if [ "$READY" = "1" ]; then
        echo "  MEDUSA is up: $(curl -s -m 2 -H "$PING_HDR" "http://127.0.0.1:$PORT/ping")"
    else
        echo ""
        echo "  WARNING: no answer on port $PORT after 20 seconds."
        if [ "$VISIBLE" = "1" ]; then
            echo "           Read the engine window -- the reason is in there."
        else
            echo "           Read $LOG -- the reason is in there."
        fi
        echo "           Common cause: another process already holds the port."
        # [05/09] Ce message promettait un repli navigateur qui n'existe plus :
        # depuis la 4.7.0, manifold.js est retire, il n'y a AUCUN repli WASM.
        echo "           NASSCAD will still open, but Union / Subtraction /"
        echo "           Intersection will refuse to run: since 4.7.0 there is"
        echo "           no in-browser fallback. Viewing, primitives, fillet,"
        echo "           measure and import/export keep working."
    fi
fi

# -- 4. Open the page --------------------------------------------------------
if [ "$OPEN_BROWSER" = "1" ]; then
    echo "  Opening $PAGE_NAME..."
    if command -v xdg-open >/dev/null 2>&1; then
        xdg-open "$PAGE" >/dev/null 2>&1 &
    elif command -v firefox >/dev/null 2>&1; then
        firefox "$PAGE" >/dev/null 2>&1 &
    else
        echo "  No browser launcher found. Open this by hand:"
        echo "    $PAGE"
    fi
fi

cat <<EOF

============================================================
  If the page was already open before the engine started:
  booleans find it at the next operation, STEP imports within
  a minute -- or press F5 to be sure. The Logs panel must show:
    "NASSCAD Engine detected (native localhost companion)"

  Stop the engine:  close its window, or  bash nasscad.sh --stop
  Watch the log:    bash nasscad.sh --log
  Headless start:   bash nasscad.sh --background
  Engine log file:  bash nasscad.sh --logfile   (off by default; the journal
                    is otherwise read on demand from the Logs panel)
============================================================
EOF
