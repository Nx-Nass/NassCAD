NASSCAD / MEDUSA - licensing update, 20 October 2026
Copyright (C) 2026 NassLab - Nasser, France.
SPDX-License-Identifier: AGPL-3.0-only

NassLab's source and build scripts in this bundle are licensed under the
GNU Affero General Public License version 3 only. See the included LICENSE.
Personal, educational, professional and commercial use is allowed.
Modification and redistribution, including for a fee, are allowed subject
to the AGPL's conditions. Provide corresponding source when required.
Modified versions used remotely over a network must offer corresponding
source to their users under AGPL section 13.

Third-party dependencies retain their respective licenses and notices.
Source, licensing details and dependency notices:
https://github.com/Nx-Nass/NassCAD
https://github.com/Nx-Nass/NassCAD/blob/main/LICENSING.md
https://github.com/Nx-Nass/NassCAD/blob/main/THIRD-PARTY.md

This bundle contains source and build scripts, not rebuilt release binaries.
The software is supplied without warranty; see LICENSE sections 15 and 16.